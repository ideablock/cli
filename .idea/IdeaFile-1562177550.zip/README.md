# ideablock-cli
Command-line version of IdeaBlock for git-like idea push in workflows.
